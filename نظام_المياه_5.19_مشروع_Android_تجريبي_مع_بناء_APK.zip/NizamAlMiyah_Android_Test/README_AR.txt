مشروع Android تجريبي — نظام المياه 5.19
========================================

يحتوي المشروع على نسخة HTML الحالية داخل تطبيق Android WebView، مع إعداد
بناء تجريبي وملف GitHub Actions لتجميع APK تلقائيًا.

بيانات المشروع:
- اسم الحزمة التجريبي: com.nizamalmiya.app
- رقم الإصدار: 5.19-test
- الحد الأدنى: Android 6.0 (API 23)
- ملف التطبيق: app/src/main/assets/index.html

تنبيه مهم:
هذا ZIP هو مصدر المشروع وليس APK جاهزًا للتثبيت.
لا تتوفر في بيئة المحادثة أدوات Android SDK/Gradle لتجميع APK مباشرة.
أضفت سير عمل GitHub Actions ليبني APK في بيئة بناء سحابية عند رفع المشروع
إلى مستودع GitHub وتشغيل Actions.

بناء APK عبر GitHub (يمكن تنفيذ الرفع من متصفح الهاتف، لكنه يتطلب حساب GitHub):
1. أنشئ مستودعًا جديدًا في GitHub.
2. ارفع محتويات هذا المشروع إلى المستودع، وليس ملف ZIP نفسه.
3. افتح تبويب Actions في المستودع.
4. اختر "Build Android Test APK" ثم "Run workflow".
5. بعد انتهاء البناء بنجاح، افتح تشغيل المهمة (workflow run).
6. نزّل Artifact باسم Nizam-AlMiyah-test-APK؛ يحتوي app-debug.apk.

أو باستخدام Android Studio على الكمبيوتر:
1. افتح مجلد المشروع.
2. انتظر Gradle Sync.
3. اختر Build > Build APK(s).
4. ملف APK التجريبي يكون عادةً في app/build/outputs/apk/debug/app-debug.apk.

تحذيرات اختبار:
- اختبر ببيانات تجريبية فقط قبل إدخال بيانات حقيقية.
- النسخ الاحتياطي إلى Google Drive غير مؤكد العمل داخل WebView؛ يحتاج إعداد
  OAuth متوافقًا مع Android أو استضافة HTTPS واختبارًا فعليًا.
- لا ترفع ملف client_secret JSON إلى GitHub ولا تضع Client Secret داخل APK.
- هذا بناء تجريبي غير موقّع للنشر في المتجر، ومخصص للتثبيت والاختبار فقط.
